package com.example.userpreferences;

import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;

import java.io.IOException;
import java.io.InputStream;

public class DirFragment extends Fragment {
    private OnChangeChapterListener fragmentSendDataListener;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_dir, container, false);
        ListView listView = view.findViewById(R.id.list_chapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                String selectedItem = (String)parent.getItemAtPosition(position);
                fragmentSendDataListener.onSendData(selectedItem);

                TextView textItem = (TextView)view;
                String filename = textItem.getText().toString().replace(" ", "");
                Log.i("TESTPREF", filename+".txt");
            }
        });
        return view;
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        try {
            fragmentSendDataListener = (OnChangeChapterListener) context;
        } catch (ClassCastException e) {
            throw new ClassCastException(context.toString()
                    + " must implement an interface OnChangeChapterListener");
        }
    }

    interface OnChangeChapterListener {
        void onSendData(String data);
    }
}