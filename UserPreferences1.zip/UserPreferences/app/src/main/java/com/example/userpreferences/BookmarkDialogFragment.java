package com.example.userpreferences;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;

public class BookmarkDialogFragment extends DialogFragment {
    private OnCreateBookmarkListener bookmarkListener;

    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        final TextView input = new TextView(getContext());
        return new AlertDialog.Builder(requireContext())
                .setMessage(R.string.input_name)
                .setView(input)
                .setPositiveButton(R.string.ok, (dialog, which) -> {
                    if (input.getText().toString().isEmpty())
                        return;
                    bookmarkListener.onSendBookmarkName(input.getText().toString());
                })
                .setNegativeButton("Cancel", (dialog, which) -> {
                    dialog.dismiss();
                })
                .create();
    }

    interface OnCreateBookmarkListener {
        void onSendBookmarkName(String data);
    }
}
