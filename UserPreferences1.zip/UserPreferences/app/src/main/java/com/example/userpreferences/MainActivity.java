package com.example.userpreferences;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toolbar;

import com.google.android.material.appbar.MaterialToolbar;

import java.io.IOException;
import java.io.InputStream;

public class MainActivity extends AppCompatActivity implements DirFragment.OnChangeChapterListener, BookmarkDialogFragment.OnCreateBookmarkListener{
    final String PREF_NAME = "UserPreferences";
    final String CHAPTER = "CHAPTER";
    private DirFragment dirFragment = new DirFragment();
    private ChapterFragment chapterFragment = new ChapterFragment();
    private SettingsFragment settingsFragment = new SettingsFragment();
    private AssetFileReader fileReader;
    private SharedPreferences sharedPreferences;

    private String currentChapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        fileReader = new AssetFileReader(getApplicationContext());
        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.content_fragment, dirFragment)
                .commit();

        sharedPreferences = getSharedPreferences(PREF_NAME, MODE_PRIVATE);

        MaterialToolbar toolbar = findViewById(R.id.top_app_bar);
        toolbar.setOnMenuItemClickListener(new androidx.appcompat.widget.Toolbar.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                if (item.getItemId() == R.id.add_bookmark) {
                    new BookmarkDialogFragment().show(getSupportFragmentManager(), "Bookmark Dialog");
                    return true;
                }
                if (item.getItemId() == R.id.delete_bookmark) {
                    return true;
                }
                if (item.getItemId() == R.id.settings) {
                    getSupportFragmentManager()
                            .beginTransaction()
                            .replace(R.id.content_fragment, settingsFragment)
                            .addToBackStack(null)
                            .commit();
                    return true;
                }
                return true;
            }
        });
    }

    @Override
    public void onSendData(String filename) {
        filename = filename.replace(" ", "");
        currentChapter = filename;
        setFragmentChapter();
    }

    private void setFragmentChapter() {
        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.content_fragment, chapterFragment)
                .addToBackStack(null)
                .commit();
        chapterFragment.setDataChapter(fileReader.readFile(currentChapter));
    }

    @Override
    protected void onPause() {
        super.onPause();
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(CHAPTER, currentChapter);
        editor.apply();
    }

    @Override
    protected void onResume() {
        super.onResume();

        currentChapter = sharedPreferences.getString(CHAPTER, "");
        if (!currentChapter.isEmpty()) {
            setFragmentChapter();
        }

    }


    @Override
    public void onSendBookmarkName(String data) {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(data, currentChapter);
        editor.apply();
    }
}