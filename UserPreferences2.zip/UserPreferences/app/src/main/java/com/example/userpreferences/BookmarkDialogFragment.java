package com.example.userpreferences;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;

public class BookmarkDialogFragment extends DialogFragment {
    private OnCreateBookmarkListener bookmarkListener;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_bookmark_dialog, null);
        EditText tvName = v.findViewById(R.id.tv_bookmark_name);

        Button addButton = v.findViewById(R.id.add_button);
        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                bookmarkListener.onSendBookmarkName(tvName.getText().toString());
                dismiss();
            }
        });
        return v;
    }

    interface OnCreateBookmarkListener {
        void onSendBookmarkName(String data);
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        try {
            bookmarkListener = (OnCreateBookmarkListener) context;
        } catch (ClassCastException e) {
            throw new ClassCastException(context.toString()
                    + " must implement an interface OnCreateBookmarkListener");
        }
    }
}
