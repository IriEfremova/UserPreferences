package com.example.userpreferences;

import android.content.res.AssetManager;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.io.IOException;
import java.io.InputStream;

public class ChapterFragment extends Fragment {
    private TextView tvChapter;
    private String dataChapter;

    public String getDataChapter() {
        return dataChapter;
    }

    public void setDataChapter(String dataChapter) {
        this.dataChapter = dataChapter;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_chapter, container, false);
        tvChapter = view.findViewById(R.id.text_chapter);
        return view;
    }


    @Override
    public void onResume() {
        super.onResume();
        tvChapter.setText(dataChapter);
    }


}